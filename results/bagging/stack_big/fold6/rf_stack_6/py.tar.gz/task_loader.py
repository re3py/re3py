def parse_settings(file_name):
    pass


def parse_data(file_name):
    pass
