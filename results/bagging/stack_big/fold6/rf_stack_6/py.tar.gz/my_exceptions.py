class WrongValueException(Exception):
    pass


class MissingValueException(Exception):
    pass
