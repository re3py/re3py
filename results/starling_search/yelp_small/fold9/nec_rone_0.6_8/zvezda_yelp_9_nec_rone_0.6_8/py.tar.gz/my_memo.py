used_comp_memo = [0, 0]
